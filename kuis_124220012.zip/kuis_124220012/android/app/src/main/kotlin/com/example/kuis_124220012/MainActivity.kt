package com.example.kuis_124220012

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
