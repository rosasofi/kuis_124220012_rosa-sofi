import 'package:flutter/material.dart';
import 'dummy_fakultas.dart';

class HomePage extends StatelessWidget {
  final String username;

  HomePage({required this.username});

  final List<Color> facultyColors = [
    Colors.orangeAccent,
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Halo, $username'),
        backgroundColor: const Color.fromARGB(255, 56, 250, 38),
      ),
      body: Column(
        children: [
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => DetailUpnPage(),
                ),
              );
            },
            child: Card(
              color: const Color.fromARGB(255, 56, 250, 38),
              margin: const EdgeInsets.all(16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15.0),
              ),
              elevation: 5,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Sudahkan kamu mengenal UPN Jogja?',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'UPN Jogja adalah kampus favorit di DIY lho!',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Kenalan lebih jauh yuk.',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 16.0),
            child: Text(
              'List Fakultas UPNYK',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: facultyList.length,
              itemBuilder: (context, index) {
                final faculty = facultyList[index];
                return Card(
                  color: facultyColors[index % facultyColors.length],
                  margin:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  elevation: 4,
                  child: ListTile(
                    leading:
                        Image.asset(faculty.imageAsset, width: 50, height: 50),
                    title: Text(faculty.name),
                    subtitle:
                        Text('Jumlah Program Studi: ${faculty.numberOfMajors}'),
                    trailing:
                        Text('Jumlah Mahasiswa: ${faculty.numberOfStudents}'),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class DetailUpnPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail UPN Yogyakarta'),
        backgroundColor: const Color.fromARGB(255, 56, 250, 38),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Image.asset('images/upn.jpg', height: 200),
            ),
            const SizedBox(height: 16),
            _buildSectionTitle('Pendidikan UPN'),
            const SizedBox(height: 16),
            _buildSectionSubtitle('Arah Pendidikan'),
            const SizedBox(height: 8),
            _buildTextContent(
              'Arah pendidikan UPN ”Veteran” Yogyakarta adalah mengembangkan ilmu pengetahuan dan teknologi yang dilandasi oleh nilai-nilai kedisiplinan, kejuangan, kreativitas, keunggulan, kebangsaan, dan kejujuran dalam rangka menunjang pembangunan nasional melalui bidang pendidikan tinggi dalam rangka terciptanya sumber daya manusia yang unggul di era global dengan dilandasi jiwa bela negara.',
            ),
            const SizedBox(height: 16),
            _buildSectionSubtitle('Tujuan Pendidikan'),
            const SizedBox(height: 8),
            _buildTextContent(
              'Pendidikan di UPN ”Veteran” Yogyakarta bertujuan untuk:',
            ),
            const SizedBox(height: 8),
            _buildTextContent(
              '1. Menyelenggarakan pendidikan dan pengajaran yang berkualitas guna menghasilkan lulusan berdaya saing global yang memiliki jiwa disiplin, berdaya juang, kreatif, serta berwawasan kebangsaan dan mampu menjadi komponen pendukung dalam sistem pertahanan negara.',
            ),
            const SizedBox(height: 8),
            _buildTextContent(
              '2. Meningkatkan kuantitas dan kualitas penelitian guna menunjang pengembangan mutu pendidikan dan pengajaran, mengembangkan dan menerapkan ilmu pengetahuan dan teknologi (IPTEK) untuk menunjang pengabdian kepada masyarakat, serta menghasilkan modal intelektual dan karya ilmiah dalam rangka menunjang pembangunan nasional.',
            ),
            const SizedBox(height: 8),
            _buildTextContent(
              '3. Mengembangkan kegiatan pengabdian kepada masyarakat melalui penyediaan layanan ilmu pengetahuan dan teknologi (IPTEK) dalam rangka meningkatkan kesejahteraan masyarakat, peningkatan keberdayaan masyarakat, dan peningkatan reputasi UPN ”Veteran” Yogyakarta.',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: TextStyle(
        fontSize: 22,
        fontWeight: FontWeight.bold,
        color: Colors.teal,
      ),
    );
  }

  Widget _buildSectionSubtitle(String subtitle) {
    return Text(
      subtitle,
      style: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: Colors.green[800],
      ),
    );
  }

  Widget _buildTextContent(String content) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Text(
          content,
          style: TextStyle(fontSize: 16, height: 1.5),
        ),
      ),
    );
  }
}
