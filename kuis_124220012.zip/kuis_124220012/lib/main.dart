import 'package:flutter/material.dart';
import 'package:kuis_124220012/login_page.dart';

void main() {
  runApp(facultyList());
}

class facultyList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'List Fakultas UPNYK',
      theme: ThemeData(),
      home: LoginPage(),
    );
  }
}
